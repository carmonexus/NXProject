NXProject Community

Este pacote usa a base instalada pelo NXProject-Setup.zip.
Se executar sem o Setup, pode ser necessario instalar o .NET Desktop Runtime 10 x64.

Como executar:
1. Instale/atualize a base com o NXProject-Setup.zip quando necessario.
2. Extraia todo o conteudo deste pacote para a pasta do NXProject.
3. Execute o arquivo NXProject.Community.exe.

Se precisar diagnosticar abertura do aplicativo, execute:
.\NXProject-Tracelog.ps1

Contato:
- Nexus XData Tecnologia Ltda
- comercial.nexus.xdata@gmail.com
