﻿NXProject Community

Como executar:
1. Extraia todo o conteudo deste .zip para uma pasta local.
2. Execute o arquivo NXProject.Community.exe.

Requisito:
- Microsoft .NET Desktop Runtime 10.0 para Windows

Se o aplicativo nao abrir por falta do .NET:
1. Instale o runtime ".NET Desktop Runtime 10.0 (x64)".
2. Depois execute novamente o NXProject.Community.exe.

Sugestao para distribuicao:
- Publique este .zip junto com uma pagina de download e um link para instalacao do .NET Desktop Runtime.

Contato:
- Nexus XData Tecnologia Ltda
- comercial.nexus.xdata@gamail.com
