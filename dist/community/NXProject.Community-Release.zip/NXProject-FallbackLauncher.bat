@echo off
:: Use este .bat apenas para diagnostico quando solicitado pelo suporte.
cd /d "%~dp0"
dotnet NXProject.Community.dll
